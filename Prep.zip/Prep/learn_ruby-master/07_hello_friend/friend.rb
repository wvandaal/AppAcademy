class Friend
	def greeting(name="")
		name.empty? ? "Hello!" : "Hello, #{name}!"
	end
end