def ftoc(temp)
	(temp - 32)*5/9.0
end

def ctof(temp)
	temp*9/5.0 + 32
end