NewReader.Models.Entry = Backbone.Model.extend({

});