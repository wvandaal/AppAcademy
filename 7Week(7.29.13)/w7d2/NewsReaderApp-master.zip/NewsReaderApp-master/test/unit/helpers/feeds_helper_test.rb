require 'test_helper'

class FeedsHelperTest < ActionView::TestCase
end
